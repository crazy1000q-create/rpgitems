package com.example.rpgitems;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;

/** Skill Damage % and Skill Cooldown Reduction % from worn Reaper pieces. */
public class ArmorStats {
    private static final EquipmentSlot[] SLOTS =
            { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

    private static double sum(Player p, int idx) {
        double s = 0;
        for (EquipmentSlot slot : SLOTS) {
            double[] v = RpgItems.ARMOR_STATS.get(p.getItemBySlot(slot).getItem());
            if (v != null) s += v[idx];
        }
        return s;
    }

    public static double skillDamageMult(Player p) { return 1.0 + sum(p, 0); }

    public static double cooldownMult(Player p) { return Math.max(0.1, 1.0 - sum(p, 1)); }
}
